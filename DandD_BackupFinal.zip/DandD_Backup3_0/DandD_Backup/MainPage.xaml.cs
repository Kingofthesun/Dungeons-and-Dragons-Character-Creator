﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.ViewManagement;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using DandD_Backup.Utils;
using DandD_Backup.Models;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace DandD_Backup
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        private int level = 1;
        private long experience = 0;
        private int proficiency = 2;
        private int inspiration = 0;
        private int strength, dexterity, constitution, intelligence, wisdom, charisma;
        private int strengthMod, dexterityMod, constitutionMod, intelligenceMod, wisdomMod, charismaMod;
        private int dexterityModTwo;
        private int strengthSavingThrow, dexteritySavingThrow, constitutionSavingThrow, intelligenceSavingThrow, wisdomSavingThrow, charismaSavingThrow;
        private int athletics, acrobatics, sleightOfHand, stealth, arcana, history, investigation, nature, religion, animalHandling, insight, medicine, perception, survival, deception, intimidation, performance, persuasion;

        public MainPage()
        {
            ApplicationView.PreferredLaunchWindowingMode = ApplicationViewWindowingMode.Maximized;
            this.InitializeComponent();
            inititalzeOther();

        }
        private void inititalzeOther()
        {
            List<Weapon> weapons = getWeapon();
            List<string> weaponNames = new List<string>();

            foreach (var item in weapons)
            {
               weaponNames.Add(item.Name);
            }
            weaponFinder.ItemsSource = weaponNames;

            List<Class> allClass = getClass();
            List<string> classNames = new List<string>();

            foreach (var item in allClass)
            {
                classNames.Add(item.ClassName);
            }

            comboBoxClass.ItemsSource = classNames;

            setLevel();
            setExperience();
            setProficiency();
            setInspiration();
        }

        private List<Weapon> getWeapon()
        {
            Weapon simMeleeOne = new Weapon("Simple Melee Weapon", "Club", 1, "sp", 1, 4, null, "Bludgeoning", "2 Lb.", new List<string>() { "Light" });
            Weapon simMeleeTwo = new Weapon("Simple Melee Weapon", "Dagger", 2, "gp", 1, 4, null, "Piercing", "1 Lb.", new List<string>() { "Finesse", "Light", "Thrown(range 20/60)" });
            Weapon simMeleeThree = new Weapon("Simple Melee Weapon", "Greatclub", 2, "sp", 1, 8, null, "10 Lb.", "Bludgeoning", new List<string>() { "Two-handed" });
            Weapon simMeleeFour = new Weapon("Simple Melee Weapon", "Handaxe", 5, "gp", 1, 6, null, "Slashing", "2 Lb.", new List<string>() { "Light", "Thrown(20/60)" });
            Weapon simMeleeSix = new Weapon("Simple Melee Weapon", "Javelin", 5, "sp", 1, 6, null, "Piercing", "2 Lb.", new List<string>() { "Thrown(range 30/120)" });
            Weapon simMeleeSeven = new Weapon("Simple Melee Weapon", "Light Hammer", 2, "gp", 1, 4, null, "Bludgeoning", "2 Lb.", new List<string>() { "Light", "Thrown(range 30/120)" });
            Weapon simMeleeEight = new Weapon("Simple Melee Weapon", "Mace", 5, "gp", 1, 6, null, "Bludgeoning", "4 Lb.", null);
            Weapon simMeleeNine = new Weapon("Simple Melee Weapon", "Quarterstaff", 2, "sp", 1, 6, null, "Bludgeoning", "4 Lb.", new List<string>() { "Versatile(1d8)" });
            Weapon simMeleeTen = new Weapon("Simple Melee Weapon", "Sickle", 1, "gp", 1, 4, null, "Slashing", "2 Lb.", new List<string>() { "Light" });
            Weapon simMeleeEleven = new Weapon("Simple Melee Weapon", "Spear", 1, "gp", 1, 6, null, "Piercing", "3 Lb.", new List<string>() { "Thrown(range 20/60)", "Versatile(1d8)" });

            Weapon simRangedOne = new Weapon("Simple Ranged Weapon", "Crossbow, Light", 25, "gp", 1, 8, null, "Piercing", "5 Lb.", new List<string>() { "Ammuniction(range 80/320)", "Loading", "Two-Handed" });
            Weapon simRangedTwo = new Weapon("Simple Ranged Weapon", "Dart", 5, "cp", 1, 4, null, "Piercing", "0.25 Lb.", new List<string>() { "Finesse", "Thrown(range 20/60)" });
            Weapon simRangedThree = new Weapon("Simple Ranged Weapon", "Shortbow", 25, "gp", 1, 6, null, "Piercing", "2 Lb.", new List<string>() { "Ammunition(range 30/120)", "Two-Handed" });
            Weapon simRangedFour = new Weapon("Simple Ranged Weapon", "Sling", 1, "sp", 1, 4, null, "Bludgeoning", null, new List<string>() { "Ammunition(range 30/120)", "Two-Handed" });

            Weapon MartialMeleeOne = new Weapon("Martial Melee Weapons", "Battleaxe", 10, "gp", 1, 8, null, "Slashing", "4 Lb.", new List<string>() { "Versatile(1d10)" });
            Weapon MartialMeleeTwo = new Weapon("Martial Melee Weapons", "Flail", 10, "gp", 1, 8, null, "Bludgeoning", "2 Lb.", null);
            Weapon MartialMeleeThree = new Weapon("Martial Melee Weapons", "Glaive", 20, "gp", 1, 10, null, "Slashing", "6 Lb.", new List<string>() { "Heavy", "Reach", "Two-handed" });
            Weapon MartialMeleeFour = new Weapon("Martial Melee Weapons", "Greataxe", 30, "gp", 1, 12, null, "Slashing", "7 Lb.", new List<string>() { "Heavy", "Two-handed" });
            Weapon MartialMeleeFive = new Weapon("Martial Melee Weapons", "Greatsword", 50, "gp", 2, 6, null, "Slashing", "6 lb.", new List<string>() { "Heavy", "Two-handed" });
            Weapon MartialMeleeSix = new Weapon("Martial Melee Weapons", "Lance", 10, "gp", 1, 12, null, "Piercing", "6 lb.", new List<string>() { "Reach", "Special" });
            Weapon MartialMeleeEight = new Weapon("Martial Melee Weapons", "Longsword", 15, "gp", 1, 8, null, "Slashing", "3 lb.", new List<string>() { "Versatile(1d10)" });
            Weapon MartialMeleeNine = new Weapon("Martial Melee Weapons", "Maul", 10, "gp", 2, 6, null, "Bludgeoning", "10 lb.", new List<string>() { "Heavy", "Two-handed" });
            Weapon MartialMeleeTen = new Weapon("Martial Melee Weapons", "Morningstar", 15, "gp", 1, 8, null, "Piercing", "4 lb.", null);
            Weapon MartialMeleeEleven = new Weapon("Martial Melee Weapons", "Pike", 5, "gp", 1, 10, null, "Piercing", "18 lb.", new List<string>() { "Heavy", "Reach", "Two-handed" });
            Weapon MartialMeleeTwelve = new Weapon("Martial Melee Weapons", "Rapier", 25, "gp", 1, 8, null, "Piercing", "2 lb.", new List<string>() { "Finesse" });
            Weapon MartialMeleeThirteen = new Weapon("Martial Melee Weapons", "Shortsword", 10, "gp", 1, 6, null, "Piercing", "2 lb.", new List<string>() { "Finesse", "Light" });
            Weapon MartialMeleeFourteen = new Weapon("Martial Melee Weapons", "Trident", 5, "gp", 1, 6, null, "Piercing", "4 lb.", new List<string>() { "Thrown(range 20/60)", "Versatile(1d8)" });
            Weapon MartialMeleeFifteen = new Weapon("Martial Melee Weapons", "War Pick", 5, "gp", 1, 8, null, "Piercing", "2 lb.", null);
            Weapon MartialMeleeSixteen = new Weapon("Martial Melee Weapons", "Warhammer", 15, "gp", 1, 8, null, "Bludgeoning", "2 lb.", new List<string>() { "Versatile(1d10)" });
            Weapon MartialMeleeSeventeen = new Weapon("Martial Melee Weapons", "Whip", 2, "gp", 1, 4, null, "Slashing", "3 lb.", new List<string>() { "Finesse", "Reach" });
            Weapon MartialMeleeEightteen = new Weapon("Martial Melee Weapons", "Scimitar", 25, "gp", 1, 6, null, "Slashing", "3 lb.", new List<string>() { "Finesse", "Light" });

            Weapon MartRangedOne = new Weapon("Martial Ranged Weapons", "Blowgun", 10, "gp", null, null, 1, "Piercing", "1 lb.", new List<string>() { "Ammunition(range 25 / 100)", "Loading" });
            Weapon MartRangedTwo = new Weapon("Martial Ranged Weapons", "Crossbow, Hand", 75, "gp", 1, 6, null, "Piercing", "3 lb.", new List<string>() { "Ammunition(range 30/120)", "Light", "Loading" });
            Weapon MartRangedThree = new Weapon("Martial Ranged Weapons", "Crossbow, Heavy", 50, "gp", 1, 10, null, "Piercing", "18 lb.", new List<string>() { "Ammunition (range 100/400)", "Heavy", "Loading", "Two-handed" });
            Weapon MartRangedFour = new Weapon("Martial Ranged Weapons", "Longbow", 50, "gp", 1, 8, null, "Piercing", "2 lb.", new List<string>() { "Ammunition(range 150/600)", "Heavy", "Two-handed" });
            Weapon MartRangedFive = new Weapon("Martial Ranged Weapons", "Net", 1, "gp", null, null, null, null, "3 lb.", new List<string>() { "Special", "Thrown(range 5/15)" });


            List<Weapon> allWeapons = new List<Weapon>() { simMeleeOne, simMeleeTwo, simMeleeThree, simMeleeFour, simMeleeSix, simMeleeSeven, simMeleeEight, simMeleeNine, simMeleeTen, simMeleeEleven, simRangedOne, simRangedTwo, simRangedThree, simRangedFour, MartialMeleeOne, MartialMeleeTwo, MartialMeleeThree, MartialMeleeFour, MartialMeleeFive, MartialMeleeSix, MartialMeleeEight, MartialMeleeNine, MartialMeleeTen, MartialMeleeEleven, MartialMeleeTwelve, MartialMeleeThirteen, MartialMeleeFourteen, MartialMeleeFifteen, MartialMeleeSixteen, MartialMeleeSeventeen, MartialMeleeEightteen, MartRangedOne, MartRangedTwo, MartRangedThree, MartRangedFour, MartRangedFive };
            return allWeapons;

            
        }

        private List<Armor> getArmor()
        {
            Armor LightArmorOne = new Armor("Light Armor", "Padded", 5, "gp", 11 + dexterityMod, null, "Disadvantage", "8 lb.");
            Armor LightArmorTwo = new Armor("Light Armor", "Leather", 10, "gp", 11 + dexterityMod, null, null, "10 lb.");
            Armor LightArmorThree = new Armor("Light Armor", "Studded Leather", 45, "gp", 12 + dexterityMod, null, null, "13 lb.");

            Armor MediumArmorOne = new Armor("Medium Armor", "Hide", 10, "gp", 12 + dexterityModTwo, null, null, "12 lb.");
            Armor MediumArmorTwo = new Armor("Medium Armor", "Chain Shirt", 50, "gp", 13 + dexterityModTwo, null, null, "20 lb.");
            Armor MediumArmorThree = new Armor("Medium Armor", "Scale Mail", 50, "gp", 14 + dexterityModTwo, null, "Disadvantage", "45 lb.");
            Armor MediumArmorFour = new Armor("Medium Armor", "Breastplate", 400, "gp", 14 + dexterityModTwo, null, null, "20 lb.");
            Armor MediumArmorFive = new Armor("Medium Armor", "Half Plate", 750, "gp", 15 + dexterityModTwo, null, "Disadvantage", "40 lb.");

            Armor HeavyArmorOne = new Armor("Heavy Armor", "Ring Mail", 30, "gp", 14, null, "Disadvantage", "40 lb.");
            Armor HeavyArmorTwo = new Armor("Heavy Armor", "Chain Mail", 75, "gp", 16, 13, "Disadvantage", "55 lb.");
            Armor HeavyArmorThree = new Armor("Heavy Armor", "Splint", 200, "gp", 17, 15, "Disadvantage", "60 lb.");
            Armor HeavyArmorFour = new Armor("Heavy Armor", "Plate", 1500, "gp", 18, 15, "Disadvantage", "65 lb.");

            List<Armor> allArmor = new List<Armor>() { LightArmorOne, LightArmorTwo, LightArmorThree, MediumArmorOne, MediumArmorTwo, MediumArmorThree, MediumArmorFour, MediumArmorFive, HeavyArmorOne, HeavyArmorTwo, HeavyArmorThree, HeavyArmorFour };
            return allArmor;
        }

        //Sets Values for Experience, Inspiration and Level
        #region SetValues

        //Takes Inspiration Value and sets it to InsperationLabel
        private void setInspiration()
        {
            InsperationLabel.Text = $"{inspiration}";
        }

        //Takes Level Value and sets it to textBlockLevel
        private void setLevel()
        {
            textBlockLevel.Text = $"{level}";
        }

        //Takes Experience Value and sets it to ExpeirenceLabel
        private void setExperience()
        {
            ExpeirenceLabel.Text = $"{experience}";
        }
        #endregion

        //Allows for the creation of a Int Only TextBlock
        #region IntTextBlockLogic
        private void TextBox_TextChanging(TextBox sender, TextBoxTextChangingEventArgs args)
        {
            bool ignoreNextTextChanged = false;
            if (ignoreNextTextChanged)
            {
                ignoreNextTextChanged = false;
                return;
            }
            else
            {
                string s = sender.Text;
                s.Trim();
                string replace = "";

                if (s.Length > 0)
                {
                    //Goes through TextBox.Text string and checks if each value is between char value 57(9)-48(0) inclusive
                    //If a char is not in that range do nothing. This only sets Sender(TextBlock).Text to chars inside the replace string
                    foreach (char item in s)
                    {
                        if (item <= 57 && item >= 48)
                        {
                            replace += item;
                        }
                    }
                }
                sender.Text = replace;

                //Sets Text Cursor at the end of TextBox
                //This allows for user to not have to set cursor back to the end of text box
                sender.SelectionStart = (replace.Length);
            }
        }
        #endregion

        private void floatBox_TextChanging(TextBox sender, TextBoxTextChangingEventArgs args)
        {
            bool ignoreNextTextChanged = false;
            if (ignoreNextTextChanged)
            {
                ignoreNextTextChanged = false;
                return;
            }
            else
            {
                string s = sender.Text;
                s.Trim();
                string replace = "";

                if (s.Length > 0)
                {
                    //Goes through TextBox.Text string and checks if each value is between char value 57(9)-48(0) inclusive
                    //If a char is not in that range do nothing. This only sets Sender(TextBlock).Text to chars inside the replace string
                    foreach (char item in s)
                    {
                        if (item <= 57 && item >= 48 || item == '.')
                        {
                            replace += item;
                        }
                    }
                }
                sender.Text = replace;

                //Sets Text Cursor at the end of TextBox
                //This allows for user to not have to set cursor back to the end of text box
                sender.SelectionStart = (replace.Length);
            }
        }

        private void stringBox_TextChanging(TextBox sender, TextBoxTextChangingEventArgs args)
        {
            bool ignoreNextTextChanged = false;
            if (ignoreNextTextChanged)
            {
                ignoreNextTextChanged = false;
                return;
            }
            else
            {
                string s = sender.Text;
                s.Trim();
                string replace = "";

                if (s.Length > 0)
                {
                    //Goes through TextBox.Text string and checks if each value is between char value 57(9)-48(0) inclusive
                    //If a char is not in that range do nothing. This only sets Sender(TextBlock).Text to chars inside the replace string
                    foreach (char item in s)
                    {
                        if (item <= 'z' && item >= 'A')
                        {
                            replace += item;
                        }
                    }
                }
                sender.Text = replace;

                //Sets Text Cursor at the end of TextBox
                //This allows for user to not have to set cursor back to the end of text box
                sender.SelectionStart = (replace.Length);
            }
        }

        #region GetClass
        private List<Class> getClass()
        {
            Class Barbarian = new Class("1d12", "Barbarian", 2, 4, 10, 12 + constitutionMod, 1, 12);
            Class Bard = new Class("1d8", "Bard", 5, 12, 10, 8 + constitutionMod, 1, 8);
            Class Cleric = new Class("1d8", "Cleric", 5, 4, 10, 8 + constitutionMod, 1, 8);
            Class Druid = new Class("1d8", "Druid", 2, 4, 10, 8 + constitutionMod, 1, 8);
            Class Fighter = new Class("1d10", "Fighter", 2, 4, 10, 10 + constitutionMod, 1, 10);
            Class Monk = new Class("1d8", "Monk", 5, 4, null, 8 + constitutionMod, 1, 8);
            Class Paladdin = new Class("1d10", "Paladdin", 5, 4, 10, 10 + constitutionMod, 1, 10);
            Class Ranger = new Class("1d10", "Ranger", 5, 4, 10, 10 + constitutionMod, 1, 10);
            Class Rouge = new Class("1d8", "Rouge", 4, 4, 10, 8 + constitutionMod, 1, 8);
            Class Sorcerer = new Class("1d6", "Sorcerer", 3, 4, 10, 6 + constitutionMod, 1, 6);
            Class Warlock = new Class("1d8", "Warlock", 4, 4, 10, 8 + constitutionMod, 1, 8);
            Class Wizard = new Class("1d6", "Wizard", 4, 4, 10, 6 + constitutionMod, 1, 6);

            return new List<Class>() {Barbarian, Bard, Cleric, Druid, Fighter, Monk, Paladdin, Ranger, Rouge, Sorcerer, Warlock, Wizard};
        }
        #endregion


        //This is methods that have full functionality, but are not implemented
        #region Unimplemented
        //This would allow for the creation of randomized Stats. Rather than the manual input that is current.
        //private void setStats()
        //{
        //    strength = statSum();
        //    dexterity = statSum();
        //    constitution = statSum();
        //    intelligence = statSum();
        //    wisdom = statSum();
        //    charisma = statSum();

        //    strengthTextBlock.Text = $"Strength: {strength}";
        //    dexterityTextBlock.Text = $"Dexterity: {dexterity}";
        //    constitutionTextBlock.Text = $"Constitution: {constitution}";
        //    intelligenceTextBlock.Text = $"Intelligence: {intelligence}";
        //    wisdomTextBlock.Text = $"Wisdom: {wisdom}";
        //    charismaTextBlock.Text = $"Charisma: {charisma}";
        //}


        #region diceMethods

        //Would allow for the creation of a singular stat automatically

        //private Random rng = new Random();
        //public int statSum()
        //{
        //    int total = 0;
        //    int tempInt = 0;
        //    List<int> diceRolls = new List<int>();

        //    for (int i = 0; i < 4; i++)
        //    {
        //        tempInt = rng.Next(1, 6);
        //        diceRolls.Add(tempInt);
        //    }

        //    int test = diceRolls[0];
        //    int min = diceRolls.Min(m => m);

        //    diceRolls.Remove(min);
        //    total = diceRolls.Sum();

        //    return total;
        //}

        //Would allow for the rolling of any amount and type of dice with the addition of a multiplier
        //Returns dice total with or without multipiler

        //public int diceRoller(int faces, int diceAmount, int? multiplier)
        //{
        //    int total = 0;
        //    List<int> diceRolls = new List<int>();

        //    for (int i = 0; i < diceAmount; i++)
        //    {
        //        diceRolls.Append(rng.Next(1, faces));
        //    }

        //    total = diceRolls.Sum();

        //    if (!(multiplier == null))
        //    {
        //        total *= (int)multiplier;
        //    }

        //    return total;
        //}
        #endregion

        #endregion


        #region LevelLogic
        /*
        * Experience Points - Level - Proficiency Bonus
        * 0-299                 1            (+2)
        * 300-899               2            (+2)
        * 900-2,699             3            (+2)
        * 2,700-6,499           4            (+2)
        * 6,500-13,999          5            (+3)
        * 14,000-22,999         6            (+3)
        * 23,000-33,999         7            (+3)
        * 34,000-47,999         8            (+3)
        * 48,000-63,999         9            (+4)
        * 64,000-84,999        10            (+4)
        * 85,000-99,999        11            (+4)
        * 100,000-119,999      12            (+4)
        * 120,000-139,999      13            (+5)
        * 140,999-164,999      14            (+5)
        * 165,000-194,999      15            (+5)
        * 195,000-224,999      16            (+5)
        * 225,000-264,999      17            (+6)
        * 265,000-304,999      18            (+6)
        * 305,000-354,999      19            (+6)
        * 355,000-LongMaxValue 20            (+6)
        */
        //This is found on page 15 of the Players Handbook
        //This is found on page 12 of PDF Players Handbook


        //Sets Level Using Experience Points
        //If Experience is between a certian range then set level & Level Text Block to corisponding range 
        #region ExperiencetoLevel
        private void expCheck()
        {
            string EPTemp = ExpeirenceLabel.Text;
            long exp = long.Parse(EPTemp);

            if (exp >= 0 && exp <= 300)
            {
                level = 1;
            }
            else if (exp > 300 && exp <= 900)
            {
                level = 2;
            }
            else if (exp > 900 && exp <= 2700)
            {
                level = 3;

            }
            else if (exp > 2700 && exp <= 6500)
            {
                level = 4;

            }
            else if (exp > 6500 && exp <= 14000)
            {
                level = 5;
            }
            else if (exp > 14000 && exp <= 23000)
            {
                level = 6;
            }
            else if (exp > 23000 && exp <= 34000)
            {
                level = 7;
            }
            else if (exp > 34000 && exp <= 48000)
            {
                level = 8;
            }
            else if (exp > 48000 && exp <= 64000)
            {
                level = 9;
            }
            else if (exp > 64000 && exp <= 85000)
            {
                level = 10;
            }
            else if (exp > 85000 && exp <= 100000)
            {
                level = 11;
            }
            else if (exp > 100000 && exp <= 120000)
            {
                level = 12;
            }
            else if (exp > 120000 && exp <= 140000)
            {
                level = 13;
            }
            else if (exp > 140000 && exp <= 165000)
            {
                level = 14;
            }
            else if (exp > 165000 && exp <= 195000)
            {
                level = 15;
            }
            else if (exp > 195000 && exp <= 225000)
            {
                level = 16;
            }
            else if (exp > 225000 && exp <= 265000)
            {
                level = 17;
            }
            else if (exp > 265000 && exp <= 305000)
            {
                level = 18;
            }
            else if (exp > 305000 && exp <= 355000)
            {
                level = 19;
            }
            else if (exp > 355000 && exp <= long.MaxValue)
            {
                level = 20;
            }
            textBlockLevel.Text = $"{level}";
        }
        #endregion

        //Sets Experience Using Level Points
        //If Level is changed then set Experience & Experience Text Block to level base Experience
        #region SetExperienceWithLevel
        private void levelCheck()
        {
            if (level == 1)
            {
                experience = 0;
            }
            else if (level == 2)
            {
                experience = 300;
            }
            else if (level == 3)
            {
                experience = 900;
            }
            else if (level == 4)
            {
                experience = 2700;
            }
            else if (level == 5)
            {
                experience = 6500;
            }
            else if (level == 6)
            {
                experience = 14000;
            }
            else if (level == 7)
            {
                experience = 23000;
            }
            else if (level == 8)
            {
                experience = 34000;
            }
            else if (level == 9)
            {
                experience = 48000;
            }
            else if (level == 10)
            {
                experience = 64000;
            }
            else if (level == 11)
            {
                experience = 85000;
            }
            else if (level == 12)
            {
                experience = 100000;
            }
            else if (level == 13)
            {
                experience = 120000;
            }
            else if (level == 14)
            {
                experience = 140000;
            }
            else if (level == 15)
            {
                experience = 165000;
            }
            else if (level == 16)
            {
                experience = 195000;
            }
            else if (level == 17)
            {
                experience = 225000;
            }
            else if (level == 18)
            {
                experience = 265000;
            }
            else if (level == 19)
            {
                experience = 305000;
            }
            else
            {
                experience = 355000;
            }
            ExpeirenceLabel.Text = $"{experience}";
            setProficiency();
        }
        #endregion


        //Sets Proficiency & Proficiency Label by using current Level or Experience
        //If Level Or Experience is between a certian range then set Proficiency Value
        #region SetProficiencyWithLevelOrExperience
        private void setProficiency()
        {
            if (level <= 4 && level >= 1 || experience > 0 && experience < 6500)
            {
                proficiency = 2;

            }
            else if (level <= 8 && level > 4 || experience > 6500 && experience < 48000)
            {
                proficiency = 3;

            }
            else if (level <= 12 && level > 8 || experience > 48000 && experience < 120000)
            {
                proficiency = 4;

            }
            else if (level <= 16 && level > 12 || experience > 120000 && experience < 225000)
            {
                proficiency = 5;

            }
            else if (level <= 20 && level > 16 || experience > 225000 && experience < long.MaxValue)
            {
                proficiency = 6;
            }

            profTextBox.Text = $"Prfociency: {proficiency}";
            //setSkillsProf();

        }
        #endregion

        #region LevelAddAndRemoveClickEvents
        //LevelUpButton_Click allows for the textBlockLevel value to be increased by one when clicked
        //Level Can't be higher than 20 or Button will do nothing.
        //If Level is below 20 it will use Method levelCheck() to set Experience & Experience Label to appropriate amount
        private void LevelUpButton_Click(object sender, RoutedEventArgs e)
        {
            if (level < 20)
            {
                textBlockLevel.Text = "";
                level++;
                textBlockLevel.Text = $"{level}";
                levelCheck();
            }
        }

        //LevelDownButton_Click allows for the textBlockLevel value to be decreased by one when clicked]
        //Level Can't be lower than 1 or Button will do nothing.
        //If Level is above 1 it will use Method levelCheck() to set Experience & Experience Label to appropriate amount
        private void LevelDownButton_Click(object sender, RoutedEventArgs e)
        {
            if (level > 1)
            {
                textBlockLevel.Text = "";
                level--;
                textBlockLevel.Text = $"{level}";
                levelCheck();
            }

        }
        #endregion

        #region ExperienceAddAndRemoveEvents
        //ExpRemoveButton_Click event allows for the removing of experience from the Experience Label and Experience Long
        //Checks if EpTextBox is not empty. If not empty is is parsed & the expCheck() methods sets level & setProficiency() sets proficiency & proficiency label
        private void ExpRemoveButton_Click(object sender, RoutedEventArgs e)
        {
            if (!(string.IsNullOrEmpty(EpTextBox.Text)))
            {
                string s = EpTextBox.Text;
                long expMinus = long.Parse(s);
                if (experience >= expMinus)
                {
                    experience -= expMinus;
                    ExpeirenceLabel.Text = $"{experience}";
                    expCheck();
                    setProficiency();

                }
                EpTextBox.Text = "";
            }

        }

        //ExpAddButton_Click event allows for the adding of experience from the Experience Label and Experience Long
        //Checks if EpTextBox is not empty. If not empty is is parsed & the expCheck() methods sets level & setProficiency() sets proficiency & proficiency label
        private void ExpAddButton_Click(object sender, RoutedEventArgs e)
        {
            if (!(string.IsNullOrEmpty(EpTextBox.Text)))
            {
                if (experience < long.MaxValue)
                {
                    string s = EpTextBox.Text;
                    long expAdd = long.Parse(s);
                    experience += expAdd;
                    ExpeirenceLabel.Text = $"{experience}";
                    expCheck();
                    setProficiency();
                }
                EpTextBox.Text = "";
            }
        }
        #endregion
        #endregion

        #region InspirationAddAndRemoveEvent
        //When InspirationAddButton_Click Event is fired it allows for the adding inspirationTextBox.Text value to be added to insperationLabel.Text
        private void InspirationAddButton_Click(object sender, RoutedEventArgs e)
        {
            if (!(string.IsNullOrEmpty(inspirationTextBox.Text)))
            {
                if (inspiration < int.MaxValue)
                {
                    string s = inspirationTextBox.Text;
                    int insAdd = int.Parse(s);
                    inspiration += insAdd;
                    InsperationLabel.Text = $"{inspiration}";
                    inspirationTextBox.Text = "";
                }
            }
        }

        //When InspirationAddButton_Click Event is fired it allows for removing inspirationTextBox.Text value to be removed from insperationLabel.Text
        private void InspirationRemoveButton_Click(object sender, RoutedEventArgs e)
        {
            if (!(string.IsNullOrEmpty(inspirationTextBox.Text)))
            {
                string s = inspirationTextBox.Text;
                int insMinus = int.Parse(s);
                if (inspiration > insMinus)
                {
                    inspiration -= insMinus;
                    InsperationLabel.Text = $"{inspiration}";
                }
                inspirationTextBox.Text = "";
            }
        }
        #endregion

        #region StatModiferSets
        //Sets Stat Modifiers
        //Sets Stat Modifier Label with the value of stat minus 10 divided by 2
        //This is found on Page 13 of the Players Handbook

        private void setModifierStrength()
        {
            strengthMod = (strength - 10) / 2;
            strengthModTextBlock.Text = $"{strengthMod}";
        }

        private void setModifierDexterity()
        {
            dexterityMod = (dexterity - 10) / 2;
            dexterityModTextBlock.Text = $"{dexterityMod}";
            if (dexterityMod < 2)
            {
                dexterityModTwo = dexterityMod;
            }
            else if (dexterityMod > 2)
            {
                dexterityModTwo = 2;
            }
            List<Armor> mainArmor = getArmor();
            List<string> armorNames = new List<string>();
            foreach (var item in mainArmor)
            {
                armorNames.Add(item.Name);
            }

            armorFinder.ItemsSource = armorNames;
        }

        private void setModifierConstitution()
        {
            constitutionMod = (constitution - 10) / 2;
            constitutionModTextBlock.Text = $"{constitutionMod}";
        }

        private void setModifierIntelligence()
        {
            intelligenceMod = (intelligence - 10) / 2;
            intelligenceModTextBlock.Text = $"{intelligenceMod}";
        }

        private void setModifierWisdom()
        {
            wisdomMod = (wisdom - 10) / 2;
            wisdomModTextBlock.Text = $"{wisdomMod}";
        }
        private void setModifierCharisma()
        {
            charismaMod = (charisma - 10) / 2;
            charismaModTextBlock.Text = $"{charismaMod}";
        }

        #endregion

        //Get Checked logic for each skill. These Methods add profciency to associated label when event Checkbox.Checked is activated
        #region GetSkillChecked

        private void getCheckedAcrobaticSkill()
        {
            if (int.Parse(acrobaticsTextBlock.Text) == 0)
            {
                acrobaticsTextBlock.Text = $"{proficiency}";
            }
            else
            {
                int currentInt = int.Parse(acrobaticsTextBlock.Text);
                currentInt += proficiency;
                acrobatics = currentInt;
                acrobaticsTextBlock.Text = $"{acrobatics}";
            }
        }

        private void getCheckedAnimalHandlingSkill()
        {
            if (int.Parse(animalhandlingTextBlock.Text) == 0)
            {
                animalhandlingTextBlock.Text = $"{proficiency}";
            }
            else
            {
                int currentInt = int.Parse(animalhandlingTextBlock.Text);
                currentInt += proficiency;
                animalHandling = currentInt;
                animalhandlingTextBlock.Text = $"{animalHandling}";
            }
        }

        private void getCheckedArcanaSkill()
        {
            if (int.Parse(arcanaTextBlock.Text) == 0)
            {
                arcanaTextBlock.Text = $"{proficiency}";
            }
            else
            {
                int currentInt = int.Parse(arcanaTextBlock.Text);
                currentInt += proficiency;
                arcana = currentInt;
                arcanaTextBlock.Text = $"{arcana}";
            }
        }

        private void getCheckedAthleticsSkill()
        {
            if (int.Parse(athleticsTextBlock.Text) == 0)
            {
                athleticsTextBlock.Text = $"{proficiency}";
            }
            else
            {
                int currentInt = int.Parse(athleticsTextBlock.Text);
                currentInt += proficiency;
                athletics = currentInt;
                athleticsTextBlock.Text = $"{athletics}";
            }
        }

        private void getCheckedDeceptionSkill()
        {
            if (int.Parse(deceptionTextBlock.Text) == 0)
            {
                deceptionTextBlock.Text = $"{proficiency}";
            }
            else
            {
                int currentInt = int.Parse(deceptionTextBlock.Text);
                currentInt += proficiency;
                deception = currentInt;
                deceptionTextBlock.Text = $"{deception}";
            }
        }

        private void getCheckedHistorySkill()
        {
            if (int.Parse(historyTextBlock.Text) == 0)
            {
                historyTextBlock.Text = $"{proficiency}";
            }
            else
            {
                int currentInt = int.Parse(historyTextBlock.Text);
                currentInt += proficiency;
                history = currentInt;
                historyTextBlock.Text = $"{history}";
            }
        }

        private void getCheckedInsightSkill()
        {
            if (int.Parse(insightTextBlock.Text) == 0)
            {
                insightTextBlock.Text = $"{proficiency}";
            }
            else
            {
                int currentInt = int.Parse(insightTextBlock.Text);
                currentInt += proficiency;
                insight = currentInt;
                insightTextBlock.Text = $"{insight}";
            }
        }

        private void getCheckedIntimidationSkill()
        {
            if (int.Parse(intimidationTextBlock.Text) == 0)
            {
                intimidationTextBlock.Text = $"{proficiency}";
            }
            else
            {
                int currentInt = int.Parse(intimidationTextBlock.Text);
                currentInt += proficiency;
                intimidation = currentInt;
                intimidationTextBlock.Text = $"{intimidation}";
            }
        }

        private void getCheckedInvestigationSkill()
        {
            if (int.Parse(investigationTextBlock.Text) == 0)
            {
                investigationTextBlock.Text = $"{proficiency}";
            }
            else
            {
                int currentInt = int.Parse(investigationTextBlock.Text);
                currentInt += proficiency;
                investigation = currentInt;
                investigationTextBlock.Text = $"{investigation}";
            }
        }

        private void getCheckedMedicineSkill()
        {
            if (int.Parse(medicineTextBlock.Text) == 0)
            {
                medicineTextBlock.Text = $"{proficiency}";
            }
            else
            {
                int currentInt = int.Parse(medicineTextBlock.Text);
                currentInt += proficiency;
                medicine = currentInt;
                medicineTextBlock.Text = $"{medicine}";
            }
        }

        private void getCheckedNatureSkill()
        {
            if (int.Parse(natureTextBlock.Text) == 0)
            {
                natureTextBlock.Text = $"{proficiency}";
            }
            else
            {
                int currentInt = int.Parse(natureTextBlock.Text);
                currentInt += proficiency;
                nature = currentInt;
                natureTextBlock.Text = $"{nature}";
            }
        }

        private void getCheckedPerceptionSkill()
        {
            if (int.Parse(perceptionTextBlock.Text) == 0)
            {
                perceptionTextBlock.Text = $"{proficiency}";
            }
            else
            {
                int currentInt = int.Parse(perceptionTextBlock.Text);
                currentInt += proficiency;
                perception = currentInt;
                perceptionTextBlock.Text = $"{perception}";
            }
        }

        private void getCheckedPerformanceSkill()
        {
            if (int.Parse(performanceTextBlock.Text) == 0)
            {
                performanceTextBlock.Text = $"{proficiency}";
            }
            else
            {
                int currentInt = int.Parse(performanceTextBlock.Text);
                currentInt += proficiency;
                performance = currentInt;
                performanceTextBlock.Text = $"{performance}";
            }
        }


        private void getCheckedPersuasionSkill()
        {
            if (int.Parse(persuasionTextBlock.Text) == 0)
            {
                persuasionTextBlock.Text = $"{proficiency}";
            }
            else
            {
                int currentInt = int.Parse(persuasionTextBlock.Text);
                currentInt += proficiency;
                persuasion = currentInt;
                persuasionTextBlock.Text = $"{persuasion}";
            }
        }

        private void getCheckedReligonSkill()
        {
            if (int.Parse(religionTextBlock.Text) == 0)
            {
                religionTextBlock.Text = $"{proficiency}";
            }
            else
            {
                int currentInt = int.Parse(religionTextBlock.Text);
                currentInt += proficiency;
                religion = currentInt;
                religionTextBlock.Text = $"{religion}";
            }
        }

        private void getCheckedSleightofhandSkill()
        {
            if (int.Parse(sleightofhandTextBlock.Text) == 0)
            {
                sleightofhandTextBlock.Text = $"{proficiency}";
            }
            else
            {
                int currentInt = int.Parse(sleightofhandTextBlock.Text);
                currentInt += proficiency;
                sleightOfHand = currentInt;
                sleightofhandTextBlock.Text = $"{currentInt}";
            }
        }

        private void getCheckedStealthSkill()
        {
            if (int.Parse(stealthTextBlock.Text) == 0)
            {
                stealthTextBlock.Text = $"{proficiency}";
            }
            else
            {
                int currentInt = int.Parse(stealthTextBlock.Text);
                currentInt += proficiency;
                stealth = currentInt;
                stealthTextBlock.Text = $"{stealth}";
            }
        }

        private void getCheckedSurvivalSkill()
        {
            if (int.Parse(survivalTextBlock.Text) == 0)
            {
                survivalTextBlock.Text = $"{proficiency}";
            }
            else
            {
                int currentInt = int.Parse(survivalTextBlock.Text);
                currentInt += proficiency;
                survival = currentInt;
                survivalTextBlock.Text = $"{survival}";
            }
        }

        #endregion

        //Activates get methods when event Chcecked is fired
        #region SkillCheckedEvents
        private void AcrobaticsSkillCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            getCheckedAcrobaticSkill();
        }

        private void AnimalhandlingSkillCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            getCheckedAnimalHandlingSkill();
        }

        private void ArcanaSkillCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            getCheckedArcanaSkill();
        }

        private void AthleticsSkillCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            getCheckedAthleticsSkill();
        }

        private void DeceptionSkillCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            getCheckedDeceptionSkill();
        }

        private void HistorySkillCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            getCheckedHistorySkill();
        }

        private void InsightSkillCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            getCheckedInsightSkill();
        }

        private void IntimidationSkillCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            getCheckedIntimidationSkill();
        }

        private void InvestigationSkillCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            getCheckedInvestigationSkill();
        }

        private void MedicineSkillCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            getCheckedMedicineSkill();
        }

        private void NatureSkillCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            getCheckedNatureSkill();
        }

        private void PerceptionSkillCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            getCheckedPerceptionSkill();
        }

        private void PerformanceSkillCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            getCheckedPerformanceSkill();
        }

        private void PersuasionSkillCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            getCheckedPersuasionSkill();
        }

        private void ReligionSkillCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            getCheckedReligonSkill();
        }

        private void SleightofhandSkillCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            getCheckedSleightofhandSkill();
        }

        private void StealthSkillCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            getCheckedStealthSkill();
        }

        private void SurvivalSkillCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            getCheckedSurvivalSkill();
        }

        #endregion

        //Get Unchecked logic for each skill. These Methods add profciency to associated label when Checkbox.Unchecked event is activated
        #region GetSkillUnchecked
        private void getUncheckedAcrobaticSkill()
        {
            if (int.Parse(acrobaticsTextBlock.Text) == 0)
            {
                acrobaticsTextBlock.Text = $"{proficiency}";
            }
            else
            {
                int currentInt = int.Parse(acrobaticsTextBlock.Text);
                if (currentInt > proficiency)
                {
                    currentInt -= proficiency;
                }
                else
                {
                    currentInt = proficiency - currentInt;
                }
                acrobatics = currentInt;
                acrobaticsTextBlock.Text = $"{animalHandling}";
            }
        }
      
        private void getUncheckedAnimalHandlingSkill()
        {
            if (int.Parse(animalhandlingTextBlock.Text) == 0)
            {
                animalhandlingTextBlock.Text = $"{proficiency}";
            }
            else
            {
                int currentInt = int.Parse(animalhandlingTextBlock.Text);
                if (currentInt > proficiency)
                {
                    currentInt -= proficiency;
                }
                else
                {
                    currentInt = proficiency - currentInt;
                }
                animalHandling = currentInt;
                animalhandlingTextBlock.Text = $"{animalHandling}";
            }
        }

        private void getUncheckedArcanaSkill()
        {
            if (int.Parse(arcanaTextBlock.Text) == 0)
            {
                arcanaTextBlock.Text = $"{proficiency}";
            }
            else
            {
                int currentInt = int.Parse(arcanaTextBlock.Text);
                if (currentInt > proficiency)
                {
                    currentInt -= proficiency;
                }
                else
                {
                    currentInt = proficiency - currentInt;
                }
                arcana = currentInt;
                arcanaTextBlock.Text = $"{arcana}";
            }
        }

        private void getUncheckedAthleticsSkill()
        {
            if (int.Parse(athleticsTextBlock.Text) == 0)
            {
                athleticsTextBlock.Text = $"{proficiency}";
            }
            else
            {
                int currentInt = int.Parse(athleticsTextBlock.Text);
                if (currentInt > proficiency)
                {
                    currentInt -= proficiency;
                }
                else
                {
                    currentInt = proficiency - currentInt;
                }
                athletics = currentInt;
                athleticsTextBlock.Text = $"{athletics}";
            }
        }

        private void getUncheckedDeceptionSkill()
        {
            if (int.Parse(deceptionTextBlock.Text) == 0)
            {
                deceptionTextBlock.Text = $"{proficiency}";
            }
            else
            {
                int currentInt = int.Parse(deceptionTextBlock.Text);
                if (currentInt > proficiency)
                {
                    currentInt -= proficiency;
                }
                else
                {
                    currentInt = proficiency - currentInt;
                }
                deception = currentInt;
                deceptionTextBlock.Text = $"{deception}";
            }
        }

        private void getUncheckedHistorySkill()
        {
            if (int.Parse(historyTextBlock.Text) == 0)
            {
                historyTextBlock.Text = $"{proficiency}";
            }
            else
            {
                int currentInt = int.Parse(historyTextBlock.Text);
                if (currentInt > proficiency)
                {
                    currentInt -= proficiency;
                }
                else
                {
                    currentInt = proficiency - currentInt;
                }
                history = currentInt;
                historyTextBlock.Text = $"{history}";
            }
        }

        private void getUncheckedInsightSkill()
        {
            if (int.Parse(insightTextBlock.Text) == 0)
            {
                insightTextBlock.Text = $"{proficiency}";
            }
            else
            {
                int currentInt = int.Parse(insightTextBlock.Text);
                if (currentInt > proficiency)
                {
                    currentInt -= proficiency;
                }
                else
                {
                    currentInt = proficiency - currentInt;
                }
                insight = currentInt;
                insightTextBlock.Text = $"{insight}";
            }
        }

        private void getUncheckedIntimidationSkill()
        {
            if (int.Parse(intimidationTextBlock.Text) == 0)
            {
                intimidationTextBlock.Text = $"{proficiency}";
            }
            else
            {
                int currentInt = int.Parse(intimidationTextBlock.Text);
                if (currentInt > proficiency)
                {
                    currentInt -= proficiency;
                }
                else
                {
                    currentInt = proficiency - currentInt;
                }
                intimidation = currentInt;
                intimidationTextBlock.Text = $"{intimidation}";
            }
        }

        private void getUncheckedInvestigationSkill()
        {
            if (int.Parse(investigationTextBlock.Text) == 0)
            {
                investigationTextBlock.Text = $"{proficiency}";
            }
            else
            {
                int currentInt = int.Parse(investigationTextBlock.Text);
                if (currentInt > proficiency)
                {
                    currentInt -= proficiency;
                }
                else
                {
                    currentInt = proficiency - currentInt;
                }
                investigation = currentInt;
                investigationTextBlock.Text = $"{investigation}";
            }
        }

        private void getUncheckedMedicineSkill()
        {
            if (int.Parse(medicineTextBlock.Text) == 0)
            {
                medicineTextBlock.Text = $"{proficiency}";
            }
            else
            {
                int currentInt = int.Parse(medicineTextBlock.Text);
                if (currentInt > proficiency)
                {
                    currentInt -= proficiency;
                }
                else
                {
                    currentInt = proficiency - currentInt;
                }
                medicine = currentInt;
                medicineTextBlock.Text = $"{medicine}";
            }
        }

        private void getUncheckedNatureSkill()
        {
            if (int.Parse(natureTextBlock.Text) == 0)
            {
                natureTextBlock.Text = $"{proficiency}";
            }
            else
            {
                int currentInt = int.Parse(natureTextBlock.Text);
                if (currentInt > proficiency)
                {
                    currentInt -= proficiency;
                }
                else
                {
                    currentInt = proficiency - currentInt;
                }
                nature = currentInt;
                natureTextBlock.Text = $"{nature}";
            }
        }

        private void getUncheckedPerceptionSkill()
        {
            if (int.Parse(perceptionTextBlock.Text) == 0)
            {
                perceptionTextBlock.Text = $"0";
            }
            else
            {
                int currentInt = int.Parse(perceptionTextBlock.Text);
                if (currentInt > proficiency)
                {
                    currentInt -= proficiency;
                }
                else
                {
                    currentInt = proficiency - currentInt;
                }
                perception = currentInt;
                perceptionTextBlock.Text = $"{perception}";
            }
        }

        private void getUncheckedPerformanceSkill()
        {
            if (int.Parse(performanceTextBlock.Text) == 0)
            {
                performanceTextBlock.Text = $"{proficiency}";
            }
            else
            {
                int currentInt = int.Parse(performanceTextBlock.Text);
                if (currentInt > proficiency)
                {
                    currentInt -= proficiency;
                }
                else
                {
                    currentInt = proficiency - currentInt;
                }
                performance = currentInt;
                performanceTextBlock.Text = $"{performance}";
            }
        }

        private void getUncheckedPersuasionSkill()
        {
            if (int.Parse(persuasionTextBlock.Text) == 0)
            {
                persuasionTextBlock.Text = $"{proficiency}";
            }
            else
            {
                int currentInt = int.Parse(persuasionTextBlock.Text);
                if (currentInt > proficiency)
                {
                    currentInt -= proficiency;
                }
                else
                {
                    currentInt = proficiency - currentInt;
                }
                persuasion = currentInt;
                persuasionTextBlock.Text = $"{persuasion}";
            }
        }

        private void getUncheckedReligonSkill()
        {
            if (int.Parse(religionTextBlock.Text) == 0)
            {
                religionTextBlock.Text = $"{proficiency}";
            }
            else
            {
                int currentInt = int.Parse(religionTextBlock.Text);
                if (currentInt > proficiency)
                {
                    currentInt -= proficiency;
                }
                else
                {
                    currentInt = proficiency - currentInt;
                }
                religion = currentInt;
                religionTextBlock.Text = $"{religion}";
            }
        }

        private void getUncheckedSleightofhandSkill()
        {
            if (int.Parse(sleightofhandTextBlock.Text) == 0)
            {
                sleightofhandTextBlock.Text = $"{proficiency}";
            }
            else
            {
                int currentInt = int.Parse(sleightofhandTextBlock.Text);
                if (currentInt > proficiency)
                {
                    currentInt -= proficiency;
                }
                else
                {
                    currentInt = proficiency - currentInt;
                }
                sleightOfHand = currentInt;
                sleightofhandTextBlock.Text = $"{currentInt}";
            }
        }

        private void getUncheckedStealthSkill()
        {
            if (int.Parse(stealthTextBlock.Text) == 0)
            {
                stealthTextBlock.Text = $"{proficiency}";
            }
            else
            {
                int currentInt = int.Parse(stealthTextBlock.Text);
                if (currentInt > proficiency)
                {
                    currentInt -= proficiency;
                }
                else
                {
                    currentInt = proficiency - currentInt;
                }
                stealth = currentInt;
                stealthTextBlock.Text = $"{stealth}";
            }
        }

        private void getUncheckedSurvivalSkill()
        {
            if (int.Parse(survivalTextBlock.Text) == 0)
            {
                survivalTextBlock.Text = $"{proficiency}";
            }
            else
            {
                int currentInt = int.Parse(survivalTextBlock.Text);
                if (currentInt > proficiency)
                {
                    currentInt -= proficiency;
                }
                else
                {
                    currentInt = proficiency - currentInt;
                }
                survival = currentInt;
                survivalTextBlock.Text = $"{survival}";
            }
        }
        #endregion

        //Activates get methods when event Unchcecked is fired
        #region SkillUnchecked

        private void AcrobaticsSkillCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            getUncheckedAcrobaticSkill();
        }

        private void AnimalhandlingSkillCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            getUncheckedAnimalHandlingSkill();
        }

        private void ArcanaSkillCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            getUncheckedArcanaSkill();
        }


        private void AthleticsSkillCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            getUncheckedAthleticsSkill();
        }

        private void DeceptionSkillCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            getUncheckedDeceptionSkill();
        }

        private void HistorySkillCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            getUncheckedHistorySkill();
        }

        private void InsightSkillCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            getUncheckedInsightSkill();
        }

        private void IntimidationSkillCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            getUncheckedIntimidationSkill();
        }

        private void InvestigationSkillCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            getUncheckedInvestigationSkill();
        }

        private void MedicineSkillCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            getUncheckedMedicineSkill();
        }

        private void NatureSkillCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            getUncheckedNatureSkill();
        }

        private void PerceptionSkillCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            getUncheckedPerceptionSkill();
        }

        private void PerformanceSkillCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            getUncheckedPerformanceSkill();
        }

        private void PersuasionSkillCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            getUncheckedPersuasionSkill();
        }

        private void ReligionSkillCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            getUncheckedReligonSkill();
        }

        private void SleightofhandSkillCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            getUncheckedSleightofhandSkill();
        }


        private void StealthSkillCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            getUncheckedStealthSkill();
        }

        private void SurvivalSkillCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            getUncheckedSurvivalSkill();
        }


        #endregion


        #region SkillLostFocusEvents
        private void AcrobaticsTextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            if (acrobaticsSkillTextBox.Text != "")
            {
                if (int.Parse(acrobaticsTextBlock.Text) == 0)
                {
                    acrobatics = int.Parse(acrobaticsSkillTextBox.Text);
                    acrobaticsTextBlock.Text = $"{acrobatics}";
                }
                else
                {
                    acrobatics += int.Parse(acrobaticsSkillTextBox.Text);
                    acrobaticsTextBlock.Text = $"{acrobatics}";
                }
            }
            acrobaticsSkillTextBox.Text = "";
        }

        private void AnimalhandlingTextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            if (animalhandlingSkillTextBox.Text != "")
            {
                if (int.Parse(animalhandlingTextBlock.Text) == 0)
                {
                    animalhandlingTextBlock.Text = animalhandlingSkillTextBox.Text;
                    animalHandling = int.Parse(animalhandlingSkillTextBox.Text);
                }
                else
                {
                    animalHandling += int.Parse(animalhandlingSkillTextBox.Text);
                }
            }
            animalhandlingSkillTextBox.Text = "";
        }

        private void ArcanaTextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            if (arcanaSkillTextBox.Text != "")
            {
                if (int.Parse(arcanaTextBlock.Text) == 0)
                {
                    arcanaTextBlock.Text = arcanaSkillTextBox.Text;
                }
                else
                {
                    arcana += int.Parse(arcanaSkillTextBox.Text);
                }
            }
            arcanaSkillTextBox.Text = "";
        }

        private void AthleticsTextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            if (athleticsSkillTextBox.Text != "")
            {

                if (int.Parse(athleticsTextBlock.Text) == 0)
                {
                    athleticsTextBlock.Text = athleticsSkillTextBox.Text;
                }
                else
                {
                    athletics += int.Parse(athleticsSkillTextBox.Text);
                }
            }
            athleticsSkillTextBox.Text = "";
        }

        private void DeceptionSkillTextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            if (deceptionSkillTextBox.Text != "")
            {

                if (int.Parse(deceptionTextBlock.Text) == 0)
                {
                    deceptionTextBlock.Text = deceptionSkillTextBox.Text;
                }
                else
                {
                    deception = int.Parse(deceptionSkillTextBox.Text);
                }
            }
            deceptionSkillTextBox.Text = "";
        }

        private void HistorySkillTextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            if (historySkillTextBox.Text != "")
            {

                if (int.Parse(historyTextBlock.Text) == 0)
                {
                    historyTextBlock.Text = historySkillTextBox.Text;
                }
                else
                {
                    history += int.Parse(historySkillTextBox.Text);
                }
            }
            historySkillTextBox.Text = "";
        }

        private void InsightSkillTextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            if (insightSkillTextBox.Text != "")
            {

                if (int.Parse(insightTextBlock.Text) == 0)
                {
                    insightTextBlock.Text = insightSkillTextBox.Text;
                }
                else
                {
                    insight += int.Parse(insightSkillTextBox.Text);
                }
            }
            insightSkillTextBox.Text = "";
        }

        private void IntimidationSkillTextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            if (intimidationSkillTextBox.Text != "")
            {

                if (int.Parse(intimidationTextBlock.Text) == 0)
                {
                    intimidationTextBlock.Text = intimidationSkillTextBox.Text;
                }
                else
                {
                    intimidation += int.Parse(intimidationSkillTextBox.Text);
                }
            }
            intimidationSkillTextBox.Text = "";
        }

        private void InvestigationSkillTextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            if (investigationSkillTextBox.Text != "")
            {
                if (int.Parse(investigationTextBlock.Text) == 0)
                {
                    investigationTextBlock.Text = investigationSkillTextBox.Text;
                }
                else
                {
                    investigation += int.Parse(investigationSkillTextBox.Text);
                }
            }
            investigationSkillTextBox.Text = "";
        }

        private void MedicineSkillTextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            if (medicineSkillTextBox.Text != "")
            {
                if (int.Parse(medicineTextBlock.Text) == 0)
                {
                    medicineTextBlock.Text = medicineSkillTextBox.Text;
                }
                else
                {
                    medicine += int.Parse(medicineSkillTextBox.Text);
                }
            }
            medicineSkillTextBox.Text = "";
        }

        private void NatureSkillTextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            if (natureSkillTextBox.Text != "")
            {
                if (int.Parse(natureTextBlock.Text) == 0)
                {
                    natureTextBlock.Text = natureSkillTextBox.Text;
                }
                else
                {
                    nature += int.Parse(natureSkillTextBox.Text);
                }
            }
            natureSkillTextBox.Text = "";
        }

        private void PerceptionSkillTextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            if (perceptionSkillTextBox.Text != "")
            {
                if (int.Parse(perceptionTextBlock.Text) == 0)
                {
                    perceptionTextBlock.Text = perceptionSkillTextBox.Text;
                }
                else
                {
                    perception += int.Parse(perceptionSkillTextBox.Text);
                }
            }
            perceptionSkillTextBox.Text = "";
        }

        private void PerformanceSkillTextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            if (performanceSkillTextBox.Text != "")
            {
                if (int.Parse(performanceTextBlock.Text) == 0)
                {
                    performanceTextBlock.Text = performanceSkillTextBox.Text;
                }
                else
                {
                    performance += int.Parse(performanceSkillTextBox.Text);
                }
            }
            performanceSkillTextBox.Text = "";
        }

        private void PersuasionSkillTextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            if (persuasionSkillTextBox.Text != "")
            {
                if (int.Parse(persuasionTextBlock.Text) == 0)
                {
                    persuasionTextBlock.Text = persuasionSkillTextBox.Text;
                }
                else
                {
                    persuasion += int.Parse(persuasionSkillTextBox.Text);
                }
            }
            persuasionSkillTextBox.Text = "";
        }

        private void ReligionSkillTextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            if (religionSkillTextBox.Text != "")
            {
                if (int.Parse(religionTextBlock.Text) == 0)
                {
                    religionTextBlock.Text = religionSkillTextBox.Text;
                }
                else
                {
                    religion += int.Parse(religionSkillTextBox.Text);
                }
            }
            religionSkillTextBox.Text = "";
        }

        private void SleightofhandSkillTextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            if (sleightofhandSkillTextBox.Text != "")
            {
                if (int.Parse(sleightofhandTextBlock.Text) == 0)
                {
                    sleightofhandTextBlock.Text = sleightofhandSkillTextBox.Text;
                }
                else
                {
                    sleightOfHand += int.Parse(sleightofhandSkillTextBox.Text);
                }
            }
            sleightofhandSkillTextBox.Text = "";
        }

        private void StealthSkillTextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            if (stealthSkillTextBox.Text != "")
            {
                if (int.Parse(stealthTextBlock.Text) == 0)
                {
                    stealthTextBlock.Text = stealthSkillTextBox.Text;
                }
                else
                {
                    stealth += int.Parse(stealthSkillTextBox.Text);
                }
            }
            stealthSkillTextBox.Text = "";
        }

        public int Survival { get; set; }

        private void SurvivalSkillTextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            if (survivalSkillTextBox.Text != "")
            {
                if (int.Parse(survivalTextBlock.Text) == 0)
                {
                    survivalTextBlock.Text = survivalSkillTextBox.Text;
                }
                else
                {
                    survival += int.Parse(survivalSkillTextBox.Text);
                }
            }
            survivalSkillTextBox.Text = "";
        }
        #endregion


        #region StatlLostFocusEvents
        private void StrengthTextbox_LostFocus(object sender, RoutedEventArgs e)
        {
            if (((TextBox)sender).Text != "")
            {
                int validation = int.Parse(((TextBox)sender).Text);
                if (validation <= 18 && validation > 0)
                {
                    Binding b = new Binding();
                    b.Source = strengthTextbox;
                    b.Path = new PropertyPath("Text");
                    b.Mode = BindingMode.OneWay;
                    strengthIntLabel.SetBinding(TextBlock.TextProperty, b);
                    string s = strengthIntLabel.Text;
                    int stat = int.Parse(s);
                    strength = stat;
                    setModifierStrength();
                    strengthIntLabel.Text = strengthTextbox.Text;
                }
                else
                {
                    StatErrorMessage.Text = "Strength stat can't be higher than 18.\n Note: All bonus are added to stats by default.";
                    statMaxFlyOut.ShowAt(strengthTextbox);
                    strengthMod = 0;
                    strengthModTextBlock.Text = $"{strengthMod}";
                    strengthIntLabel.Text = "0";
                }
            }
            else
            {
                strengthIntLabel.Text = "0";
                strengthModTextBlock.Text = "0";
                //strengthIntLabel.Text = strengthTextbox.Text;
            }
            strengthTextbox.Text = "";
        }

        private void DexterityTextBox_LostFocus(object sender, RoutedEventArgs e)
        {

            if (((TextBox)sender).Text != "")
            {
                int validation = int.Parse(((TextBox)sender).Text);
                if (validation <= 18 && validation > 0)
                {
                    Binding b = new Binding();
                    b.Source = dexterityTextBox;
                    b.Path = new PropertyPath("Text");
                    b.Mode = BindingMode.OneWay;
                    dexterityIntLabel.SetBinding(TextBlock.TextProperty, b);
                    string s = dexterityIntLabel.Text;
                    int stat = int.Parse(s);
                    dexterity = stat;
                    setModifierDexterity();
                    dexterityIntLabel.Text = dexterityTextBox.Text;
                }
                else
                {
                    StatErrorMessage.Text = "Dexterity stat can't be higher than 18.\n Note: All bonus are added to stats by default.";
                    statMaxFlyOut.ShowAt(dexterityTextBox);
                    dexterityIntLabel.Text = "0";
                }
            }
            else
            {
                dexterityIntLabel.Text = "0";
                dexterityModTextBlock.Text = "0";
                //dexterityIntLabel.Text = dexterityTextBox.Text;
            }
            dexterityTextBox.Text = "";
        }

        private void ConstitutionTextBox_LostFocus(object sender, RoutedEventArgs e)
        {


            if (((TextBox)sender).Text != "")
            {
                int validation = int.Parse(((TextBox)sender).Text);
                if (validation <= 18 && validation > 0)
                {
                    Binding b = new Binding();
                    b.Source = constitutionTextBox;
                    b.Path = new PropertyPath("Text");
                    b.Mode = BindingMode.OneWay;
                    constitutionIntLabel.SetBinding(TextBlock.TextProperty, b);
                    string s = constitutionIntLabel.Text;
                    int stat = int.Parse(s);
                    constitution = stat;
                    setModifierConstitution();
                    constitutionIntLabel.Text = constitutionTextBox.Text;
                }
                else
                {
                    StatErrorMessage.Text = "Constitution stat can't be higher than 18.\n Note: All bonus are added to stats by default.";
                    statMaxFlyOut.ShowAt(constitutionTextBox);
                    constitutionIntLabel.Text = "0";
                }
            }
            else
            {
                constitutionIntLabel.Text = "0";
                constitutionModTextBlock.Text = "0";
                //constitutionIntLabel.Text = constitutionTextBox.Text;
            }
            constitutionTextBox.Text = "";
        }

        private void IntelligenceTextBox_LostFocus(object sender, RoutedEventArgs e)
        {


            if (((TextBox)sender).Text != "")
            {
                int validation = int.Parse(((TextBox)sender).Text);
                if (validation <= 18 && validation > 0)
                {
                    Binding b = new Binding();
                    b.Source = intelligenceTextBox;
                    b.Path = new PropertyPath("Text");
                    b.Mode = BindingMode.OneWay;
                    intelligenceIntLabel.SetBinding(TextBlock.TextProperty, b);
                    string s = intelligenceIntLabel.Text;
                    int stat = int.Parse(s);
                    intelligence = stat;
                    setModifierIntelligence();
                    intelligenceIntLabel.Text = intelligenceTextBox.Text;
                }
                else
                {
                    StatErrorMessage.Text = "Intelligence stat can't be higher than 18.\n Note: All bonus are added to stats by default.";
                    statMaxFlyOut.ShowAt(intelligenceTextBox);
                    intelligenceIntLabel.Text = "0";
                }
            }
            else
            {
                intelligenceIntLabel.Text = "0";
                intelligenceModTextBlock.Text = "0";
                //intelligenceIntLabel.Text = intelligenceTextBox.Text;
            }
            intelligenceTextBox.Text = "";
        }

        private void WisdomTextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            if (((TextBox)sender).Text != "")
            {
                int validation = int.Parse(((TextBox)sender).Text);
                if (validation <= 18 && validation > 0)
                {
                    Binding b = new Binding();
                    b.Source = wisdomTextBox;
                    b.Path = new PropertyPath("Text");
                    b.Mode = BindingMode.OneWay;
                    wisdomIntLabel.SetBinding(TextBlock.TextProperty, b);
                    string s = wisdomIntLabel.Text;
                    int stat = int.Parse(s);
                    wisdom = stat;
                    setModifierWisdom();
                    wisdomIntLabel.Text = wisdomTextBox.Text;
                }
                else
                {
                    StatErrorMessage.Text = "Wisdom stat can't be higher than 18.\n Note: All bonus are added to stats by default.";
                    statMaxFlyOut.ShowAt(wisdomTextBox);
                    intelligenceIntLabel.Text = "0";
                }
            }
            else
            {
                wisdomIntLabel.Text = "0";
                wisdomModTextBlock.Text = "0";
                //wisdomIntLabel.Text = wisdomTextBox.Text;
            }
            wisdomTextBox.Text = "";

        }

        private void CharismaTextBlock_LostFocus(object sender, RoutedEventArgs e)
        {

            if (((TextBox)sender).Text != "")
            {
                int validation = int.Parse(((TextBox)sender).Text);
                if (validation <= 18 && validation > 0)
                {
                    Binding b = new Binding();
                    b.Source = charismaTextBlock;
                    b.Path = new PropertyPath("Text");
                    b.Mode = BindingMode.OneWay;
                    charismaIntLabel.SetBinding(TextBlock.TextProperty, b);
                    string s = charismaIntLabel.Text;
                    int stat = int.Parse(s);
                    charisma = stat;
                    setModifierCharisma();
                    charismaIntLabel.Text = charismaTextBlock.Text;
                }
                else
                {
                    StatErrorMessage.Text = "Charisma stat can't be higher than 18.\n Note: All bonus are added to stats by default.";
                    statMaxFlyOut.ShowAt(charismaTextBlock);
                    intelligenceIntLabel.Text = "0";
                }
            }
            else
            {
                charismaIntLabel.Text = "0";
                charismaModTextBlock.Text = "0";
                //charismaIntLabel.Text = charismaTextBlock.Text;
            }
            charismaTextBlock.Text = "";
        }

        #endregion


        //Flyout Menu Okay button Click event
        private void OkayButton_Click(object sender, RoutedEventArgs e)
        {
            statMaxFlyOut.Hide();
        }

       
        private void SubmitButton_Click(object sender, RoutedEventArgs e)
        {

        }

        private void IdealComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void ItemRemoveButton_Click(object sender, RoutedEventArgs e)
        {

        }

        private void ItemAddButton_Click(object sender, RoutedEventArgs e)
        {

        }

        private void WaeponAddButton_Click(object sender, RoutedEventArgs e)
        {

        }

        private void WeaponRemoveButton_Click(object sender, RoutedEventArgs e)
        {

        }
    }

}