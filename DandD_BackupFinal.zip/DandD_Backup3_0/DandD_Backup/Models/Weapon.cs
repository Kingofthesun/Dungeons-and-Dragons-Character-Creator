﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DandD_Backup.Models
{
    class Weapon
    {
        public string Type { get; set; }
        public string Name { get; set; }
        public string Desc { get; set; }
        public int? CostAmount { get; set; }
        public string CoinType { get; set; }
        public string Weight { get; set; }
        public int? DamageDiceFace { get; set; }
        public int? DamageDiceAmount { get; set; }
        public int? DamageInt { get; set; }
        public string DamageName { get; set; }
        public IEnumerable<string> Properties { get; set; }


        public Weapon(string type, string name, int? costAmount, string coinType, int? diceAmount, int? diceFace, int? damageInt, string damageName, string weight, IEnumerable<string> properties)
        {
            this.Type = type;
            this.Name = name;
            this.CostAmount = costAmount;
            this.CoinType = coinType;
            this.Weight = weight;
            this.DamageDiceFace = diceFace;
            this.DamageDiceAmount = diceAmount;
            this.DamageInt = damageInt;
            this.DamageName = damageName;
            this.Properties = properties;
        }
    }

   
}
