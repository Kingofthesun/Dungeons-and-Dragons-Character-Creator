﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DandD_Backup.Models
{
    class Class
    {
        public string HitDice { get; set; }
        public string ClassName { get; set; }
        public int WealthDiceAmount { get; set; }
        public int WealthDiceFace { get; set; }
        public int? WealthDiceMultiplier { get; set; }
        public int HitPointNextDiceAmount { get; set; }
        public int HitPointNextDiceFace { get; set; }
        public int HitPointFirst { get; set; }


        public Class(string hitdice, string classname, int wealthDiceAmount, int wealthDiceFace, int? wealthDiceMultiplier, int hitPointFirst,
            int hitPointNextDiceAmount, int hitPointNextDiceFace)
        {
            HitDice = hitdice;
            ClassName = classname;
            WealthDiceAmount = wealthDiceAmount;
            WealthDiceFace = wealthDiceFace;
            WealthDiceMultiplier = wealthDiceMultiplier;
            HitPointFirst = hitPointFirst;
            HitPointNextDiceAmount = hitPointNextDiceAmount;
            HitPointNextDiceFace = hitPointNextDiceFace;

        }


    }
}
