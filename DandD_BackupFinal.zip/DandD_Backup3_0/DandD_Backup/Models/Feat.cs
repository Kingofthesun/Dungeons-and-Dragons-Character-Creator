﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DandD_Backup.Models
{
    public class Feat
    {
        public string Name { get; set; }
        public int Level { get; set; }
        public int? StrengthMod { get; set; }
        public int? ConsMod { get; set; }
        public int? WisdomMod { get; set; }
        public int? CharacterMod { get; set; }
        public int? IntelligenceMod { get; set; }
        public int? DexterityMod { get; set; }

        public Feat(string name, int level, int? strengthMod, int? consMod, int? wisdomMod, int? characterMod, int? intelligenceMod,
            int? dexterityMod)
        {
            Name = name;
            Level = level;
            StrengthMod = strengthMod;
            ConsMod = consMod;
            WisdomMod = wisdomMod;
            CharacterMod = characterMod;
            IntelligenceMod = intelligenceMod;
            DexterityMod = dexterityMod;

        }

    }
}
