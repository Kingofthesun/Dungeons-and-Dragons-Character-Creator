﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DandD_Backup.Models
{

    class Armor
    {

        public string Type { get; set; }
        public string Name { get; set; }
        public  int ArmorClass { get; set; }
        public int? Strength { get; set; }
        public string Stealth { get; set; }
        public int? CostAmount { get; set; }
        public string CoinType { get; set; }
        public string Weight { get; set; }


        public Armor(string type, string name, int? costAmount,  string coinType, int armorClass, int? strength, string stealth, string weight)
        {
            Type = type;
            Name = name;
            ArmorClass = armorClass;
            Strength = strength;
            Stealth = stealth;
            CostAmount = costAmount;
            CoinType = coinType;
            Weight = weight;
        }
    }
}
