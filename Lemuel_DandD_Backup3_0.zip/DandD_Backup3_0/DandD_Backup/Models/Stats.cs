﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DandD_Backup.Models
{
    class Stats
    {
        public IEnumerable<string> statSet { get; set; }

        public Stats()
        {
            List<string> stats = new List<string> {"Strenght","Dexterity","Constitution","Intelligence","Wisdom","Charisma"};
            statSet = stats;
        }
    }
}
