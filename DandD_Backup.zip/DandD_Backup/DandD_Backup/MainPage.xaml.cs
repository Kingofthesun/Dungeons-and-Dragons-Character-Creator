﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.ViewManagement;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace DandD_Backup
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        private static int level = 1;
        public MainPage()
        {
            this.InitializeComponent();
            var localSettings = Windows.Storage.ApplicationData.Current.LocalSettings;
            setLevel();
        }

        private void setLevel()
        {
            textBlockLevel.Text = $"{level}";
        }

        private void LevelUpButton_Click(object sender, RoutedEventArgs e)
        {
            if (level < 20)
            {
                textBlockLevel.Text = "";
                level++;
                textBlockLevel.Text = $"{level}";
            }
            else
            {

            }
        }

        private void LevelDownButton_Click(object sender, RoutedEventArgs e)
        {
            if (level > 1)
            {
                textBlockLevel.Text = "";
                level--;
                textBlockLevel.Text = $"{level}";
            }
            else
            {

            }
        }
    }
}
