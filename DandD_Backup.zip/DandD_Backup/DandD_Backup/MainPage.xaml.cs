﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.ViewManagement;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using DandD_Backup.Utilites;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace DandD_Backup
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        private int level = 1;
        private long experience = 0;
        private int proficiency = 2;
        private int inspiration = 0;
        private int strength = 0;
        private int dexterity = 0;
        private int constitution = 0;
        private int intelligence = 0;
        private int wisdom = 0;
        private int charisma = 0;



        public MainPage()
        {
            ApplicationView.PreferredLaunchWindowingMode = ApplicationViewWindowingMode.Maximized;
            this.InitializeComponent();
            inititalzeOther();

        }
        private void inititalzeOther()
        {
            setLevel();
            setExperience();
            setProficiency();
            setStats();
            setInspiration();
            defaultPivotNames();
        }

        private void defaultPivotNames()
        {
            pivotOne.Header = "Character's Information";
            pivotTwo.Header = "Character's Inventory";
            pivotThree.Header = "Character's Appearance";
            pivotFour.Header = "Character's Backstory";
            pivotFive.Header = "Character's Spell Sheet";
        }

        private void setInspiration()
        {
            InsperationLabel.Text = $"{inspiration}";
        }
        public void setStats()
        {
            strength = statSum();
            dexterity = statSum();
            constitution = statSum();
            intelligence = statSum();
            wisdom = statSum();
            charisma = statSum();

            strengthTextBlock.Text = $"Strength: {strength}";
            dexterityTextBlock.Text = $"Dexterity: {dexterity}";
            constitutionTextBlock.Text = $"Constitution: {constitution}";
            intelligenceTextBlock.Text = $"Intelligence: {intelligence}";
            wisdomTextBlock.Text = $"Wisdom: {wisdom}";
            charismaTextBlock.Text = $"Charisma: {charisma}";
        }

        private void setProficiency()
        {
        }

        #region LevelLogic
        //Sets Level Using Experience Points
        private void expCheck()
        {
            string EPTemp = ExpeirenceLabel.Text;
            long exp = long.Parse(EPTemp);

            if (exp > 0 && exp < 300)
            {
                level = 1;
                proficiency = 2;
            }
            else if (exp > 300 && exp < 900)
            {
                level = 2;
                proficiency = 2;
            }
            else if (exp > 900 && exp < 2700)
            {
                level = 3;
                proficiency = 2;

            }
            else if (exp > 2700 && exp < 6500)
            {
                level = 4;
                proficiency = 2;

            }
            else if (exp > 6500 && exp < 14000)
            {
                level = 5;
                proficiency = 3;
            }
            else if (exp > 14000 && exp < 23000)
            {
                level = 6;
                proficiency = 3;
            }
            else if (exp > 23000 && exp < 34000)
            {
                level = 7;
                proficiency = 3;
            }
            else if (exp > 34000 && exp < 48000)
            {
                level = 8;
                proficiency = 3;
            }
            else if (exp > 48000 && exp < 64000)
            {
                level = 9;
                proficiency = 4;
            }
            else if (exp > 64000 && exp < 85000)
            {
                level = 10;
                proficiency = 4;
            }
            else if (exp > 85000 && exp < 100000)
            {
                level = 11;
                proficiency = 4;

            }
            else if (exp > 100000 && exp < 120000)
            {
                level = 12;
                proficiency = 4;
            }
            else if (exp > 120000 && exp < 140000)
            {
                level = 13;
                proficiency = 5;
            }
            else if (exp > 140000 && exp < 165000)
            {
                level = 14;
                proficiency = 5;
            }
            else if (exp > 165000 && exp < 195000)
            {
                level = 15;
                proficiency = 5;
            }
            else if (exp > 195000 && exp < 225000)
            {
                level = 16;
                proficiency = 5;
            }
            else if (exp > 225000 && exp < 265000)
            {
                level = 17;
                proficiency = 6;
            }
            else if (exp > 265000 && exp < 305000)
            {
                level = 18;
                proficiency = 6;
            }
            else if (exp > 305000 && exp < 355000)
            {
                level = 19;
                proficiency = 6;
            }
            else if (exp > 355000 && exp < long.MaxValue)
            {
                level = 20;
                proficiency = 6;
            }
            textBlockLevel.Text = $"{level}";


        }

        private void levelCheck()
        {
            if (level == 1)
            {
                experience = 0;
            }
            else if (level == 2)
            {
                experience = 300;
            }
            else if (level == 3)
            {
                experience = 900;
            }
            else if (level == 4)
            {
                experience = 2700;
            }
            else if (level == 5)
            {
                experience = 6500;
            }
            else if (level == 6)
            {
                experience = 14000;
            }
            else if (level == 7)
            {
                experience = 23000;
            }
            else if (level == 8)
            {
                experience = 34000;
            }
            else if (level == 9)
            {
                experience = 48000;
            }
            else if (level == 10)
            {
                experience = 64000;
            }
            else if (level == 11)
            {
                experience = 85000;
            }
            else if (level == 12)
            {
                experience = 100000;
            }
            else if (level == 13)
            {
                experience = 120000;
            }
            else if (level == 14)
            {
                experience = 140000;
            }
            else if (level == 15)
            {
                experience = 165000;
            }
            else if (level == 16)
            {
                experience = 195000;
            }
            else if (level == 17)
            {
                experience = 225000;
            }
            else if (level == 18)
            {
                experience = 265000;
            }
            else if (level == 19)
            {
                experience = 305000;
            }
            else
            {
                experience = 355000;
            }
            ExpeirenceLabel.Text = $"{experience}";
        }

        private void setLevel()
        {
            textBlockLevel.Text = $"{level}";
        }
        private void setExperience()
        {
            ExpeirenceLabel.Text = $"{experience}";
        }

        private void LevelUpButton_Click(object sender, RoutedEventArgs e)
        {
            if (level < 20)
            {
                textBlockLevel.Text = "";
                level++;
                textBlockLevel.Text = $"{level}";
                levelCheck();
            }
        }

        private void LevelDownButton_Click(object sender, RoutedEventArgs e)
        {
            if (level > 1)
            {
                textBlockLevel.Text = "";
                level--;
                textBlockLevel.Text = $"{level}";
                levelCheck();
            }

        }

        //Method Event Handler that forces EpTextBox to be a number only text box
        private void TextBox_TextChanging(TextBox sender, TextBoxTextChangingEventArgs args)
        {
            bool ignoreNextTextChanged = false;
            if (ignoreNextTextChanged)
            {
                ignoreNextTextChanged = false;
                return;
            }
            // All other scenarios other than the backspace scenario.
            // Do the auto complete. 
            else
            {
                string s = sender.Text;
                s.Trim();
                string replace = "";

                if (s.Length > 0)
                {
                    foreach (char item in s)
                    {
                        if (item <= 57 && item >= 48)
                        {
                            replace += item;
                        }
                    }
                }

                sender.Text = replace;
                sender.SelectionStart = (replace.Length);
            }
        }

        private void ExpRemoveButton_Click(object sender, RoutedEventArgs e)
        {
            if (!(string.IsNullOrEmpty(EpTextBox.Text)))
            {
                string s = EpTextBox.Text;
                long expMinus = long.Parse(s);
                if (experience > expMinus)
                {
                    experience -= expMinus;
                    ExpeirenceLabel.Text = $"{experience}";
                    EpTextBox.Text = "";
                }
                expCheck();
            }

        }

        private void ExpAddButton_Click(object sender, RoutedEventArgs e)
        {
            if (!(string.IsNullOrEmpty(EpTextBox.Text)))
            {
                if (experience < long.MaxValue)
                {
                    string s = EpTextBox.Text;
                    long expAdd = long.Parse(s);
                    experience += expAdd;
                    ExpeirenceLabel.Text = $"{experience}";
                    expCheck();
                    EpTextBox.Text = "";
                }
            }
        }
        #endregion
        private void InspirationAddButton_Click(object sender, RoutedEventArgs e)
        {
            if (!(string.IsNullOrEmpty(inspirationTextBox.Text)))
            {
                if (inspiration < int.MaxValue)
                {
                    string s = inspirationTextBox.Text;
                    int insAdd = int.Parse(s);
                    inspiration += insAdd;
                    InsperationLabel.Text = $"{inspiration}";
                    inspirationTextBox.Text = "";
                }
            }
        }

        private void InspirationRemoveButton_Click(object sender, RoutedEventArgs e)
        {
            if (!(string.IsNullOrEmpty(inspirationTextBox.Text)))
            {
                string s = inspirationTextBox.Text;
                int insMinus = int.Parse(s);
                if (inspiration > insMinus)
                {
                    inspiration -= insMinus;
                    InsperationLabel.Text = $"{inspiration}";
                }
                inspirationTextBox.Text = "";
            }
        }

        private Random rng = new Random();
        public int statSum()
        {
            int total = 0;
            int tempInt = 0;
            List<int> diceRolls = new List<int>();

            for (int i = 0; i < 4; i++)
            {
                tempInt = rng.Next(1, 6);
                diceRolls.Add(tempInt);
            }

            int test = diceRolls[0];
            int min = diceRolls.Min(m => m);

            diceRolls.Remove(min);
            total = diceRolls.Sum();

            return total;
        }

        public int diceRoller(int faces, int diceAmount, int? multiplier)
        {
            int total = 0;
            List<int> diceRolls = new List<int>();

            for (int i = 0; i < diceAmount; i++)
            {
                diceRolls.Append(rng.Next(1, faces));
            }

            total = diceRolls.Sum();

            if (!(multiplier == null))
            {
                total *= (int)multiplier;
            }

            return total;
        }

    }


}
