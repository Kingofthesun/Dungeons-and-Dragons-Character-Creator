﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.ViewManagement;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using DandD_Backup.Utilites;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace DandD_Backup
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        private static int level = 1;
        private static long experience = 0;

        public MainPage()
        {
            this.InitializeComponent();
            ApplicationView.PreferredLaunchWindowingMode = ApplicationViewWindowingMode.Maximized;
            inititalzeOther();

        }
        private void inititalzeOther()
        {
            setLevel();
            setExperience();
            defaultPivotNames();
        }

        //Sets Level Using Experience Points
        private void expCheck()
        {
            string EPTemp = ExpeirenceLabel.Text;
            long exp = long.Parse(EPTemp);

            if (exp > 0 && exp < 300)
            {
                level = 1;
            }
            else if (exp > 300 && exp < 900)
            {
                level = 2;
            }
            else if (exp > 900 && exp < 2700)
            {
                level = 3;
            }
            else if (exp > 2700 && exp < 6500)
            {
                level = 4;
            }
            else if (exp > 6500 && exp < 14000)
            {
                level = 5;
            }
            else if (exp > 14000 && exp < 23000)
            {
                level = 6;
            }
            else if (exp > 23000 && exp < 34000)
            {
                level = 7;
            }
            else if (exp > 34000 && exp < 48000)
            {
                level = 8;
            }
            else if (exp > 48000 && exp < 64000)
            {
                level = 9;
            }
            else if (exp > 64000 && exp < 85000)
            {
                level = 10;
            }
            else if (exp > 85000 && exp < 100000)
            {
                level = 11;
            }
            else if (exp > 100000 && exp < 120000)
            {
                level = 12;
            }
            else if (exp > 120000 && exp < 140000)
            {
                level = 13;
            }
            else if (exp > 140000 && exp < 165000)
            {
                level = 14;
            }
            else if (exp > 165000 && exp < 195000)
            {
                level = 15;
            }
            else if (exp > 195000 && exp < 225000)
            {
                level = 16;
            }
            else if (exp > 225000 && exp < 265000)
            {
                level = 17;
            }
            else if (exp > 265000 && exp < 305000)
            {
                level = 18;
            }
            else if (exp > 305000 && exp < 355000)
            {
                level = 19;
            }
            else if (exp > 355000 && exp < long.MaxValue)
            {
                level = 20;
            }
            textBlockLevel.Text = $"{level}";
        }

        private void levelCheck()
        {
            if (level == 1)
            {
                experience = 0;
            }
            else if (level == 2)
            {
                experience = 300;
            }
            else if (level == 3)
            {
                experience = 900;
            }
            else if (level == 4)
            {
                experience = 2700;
            }
            else if (level == 5)
            {
                experience = 6500;
            }
            else if (level == 6)
            {
                experience = 14000;
            }
            else if (level == 7)
            {
                experience = 23000;
            }
            else if (level == 8)
            {
                experience = 34000;
            }
            else if (level == 9)
            {
                experience = 48000;
            }
            else if (level == 10)
            {
                experience = 64000;
            }
            else if (level == 11)
            {
                experience = 85000;
            }
            else if (level == 12)
            {
                experience = 100000;
            }
            else if (level == 13)
            {
                experience = 120000;
            }
            else if (level == 14)
            {
                experience = 140000;
            }
            else if (level == 15)
            {
                experience = 165000;
            }
            else if (level == 16)
            {
                experience = 195000;
            }
            else if (level == 17)
            {
                experience = 225000;
            }
            else if (level == 18)
            {
                experience = 265000;
            }
            else if (level == 19)
            {
                experience = 305000;
            }
            else
            {
                experience = 355000;
            }
            ExpeirenceLabel.Text = $"{experience}";
        }


        private void setLevel()
        {
            textBlockLevel.Text = $"{level}";
        }
        private void setExperience()
        {
            ExpeirenceLabel.Text = $"{experience}";
        }

        private void LevelUpButton_Click(object sender, RoutedEventArgs e)
        {
            if (level < 20)
            {
                textBlockLevel.Text = "";
                level++;
                textBlockLevel.Text = $"{level}";
                levelCheck();
            }
            else
            {

            }
        }

        private void LevelDownButton_Click(object sender, RoutedEventArgs e)
        {
            if (level > 1)
            {
                textBlockLevel.Text = "";
                level--;
                textBlockLevel.Text = $"{level}";
                levelCheck();
            }
            else
            {

            }
        }
        private void defaultPivotNames()
        {
            pivotOne.Header = "Character's Information";
            pivotTwo.Header = "Character's Stats";
            pivotThree.Header = "Character's Appearance";
            pivotFour.Header = "Character's Backstory";
            pivotFive.Header = "Character's Spell Sheet";
        }

        private void TextBox_TextChanging(TextBox sender, TextBoxTextChangingEventArgs args)
        {
            bool ignoreNextTextChanged = false;
            if (ignoreNextTextChanged)
            {
                ignoreNextTextChanged = false;
                return;
            }
            // All other scenarios other than the backspace scenario.
            // Do the auto complete. 
            else
            {
                string s = sender.Text;
                s.Trim();
                string replace = "";

                if (s.Length > 0)
                {
                    foreach (char item in s)
                    {
                        if (item <= 57 && item >= 48)
                        {
                            replace += item;
                        }
                        else
                        {

                        }
                    }
                }
                else
                {

                }
                sender.Text = replace;
                sender.SelectionStart = (replace.Length);
            }
        }

        private void ExpRemoveButton_Click(object sender, RoutedEventArgs e)
        {
            if (!(string.IsNullOrEmpty(EpTextBox.Text)))
            {
                string s = EpTextBox.Text;
                long expMinus = long.Parse(s);
                if (experience > expMinus)
                {
                    experience -= expMinus;
                    ExpeirenceLabel.Text = $"{experience}";
                }
                EpTextBox.Text = "";
                expCheck();
            }

        }

        private void ExpAddButton_Click(object sender, RoutedEventArgs e)
        {
            if (!(string.IsNullOrEmpty(EpTextBox.Text)))
            {
                if (experience > long.MaxValue)
                {
                    string s = EpTextBox.Text;
                    long expAdd = long.Parse(s);
                    experience += expAdd;
                    ExpeirenceLabel.Text = $"{experience}";
                    EpTextBox.Text = "";
                    expCheck();
                }
            }
        }
    }
}
