﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace DandD_Backup.Utilites
{
    public class DiceClass
    {
        private static Random rng = new Random();
        public static int statSum()
        {
            int total = 0;
            List<int> diceRolls = new List<int>();

            for (int i = 0; i < diceRolls.Count(); i++)
            {
                diceRolls.Append(rng.Next(0, 6));
            }

            int min = diceRolls.Min();

            diceRolls.Remove(min);
            total = diceRolls.Sum();

            return total;
        }
    }
}
