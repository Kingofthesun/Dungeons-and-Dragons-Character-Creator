﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DandD_Backup.Models
{
    class Feature
    {
        public string featureName { get; set; }
        public string featureDesc { get; set; }
        public IEnumerable<int> levels { get; set; }
    }
}
