﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DandD_Backup.Models
{
    class Class
    {
        public int hitDiceAmount { get; set; }
        public int hitDiceFace { get; set; }
        public string className { get; set; }
        public int wealthDiceAmount { get; set; }
        public int wealthDiceFace { get; set; }
        public int wealthDiceMultiplier { get; set; }
        public int additionModifier { get; set; }
        public int nextLevelHPModifier { get; set; }
        public int nextLevelHpModifierDiceAmount { get; set; }
        public int nextLevelHpModifierDiceFace { get; set; }
        public string SavingThrows { get; set; }


        //public IEnumerable<string> features { get; set; }
        //public string size { get; set; }
        //public IEnumerable< statBonus { get; set; }


    }
}
