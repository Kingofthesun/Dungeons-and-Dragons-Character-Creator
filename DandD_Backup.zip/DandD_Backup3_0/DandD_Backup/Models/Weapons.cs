﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DandD_Backup.Models
{
    class Weapons
    {
        public string type { get; set; }
        public string name { get; set; }
        public string desc { get; set; }
        public int? costAmount { get; set; }
        public string coinType { get; set; }
        public string weight { get; set; }
        public int? damageDiceFace { get; set; }
        public int? damageDiceAmount { get; set; }
        public int? damageInt { get; set; }
        public string damageName { get; set; }
        public IEnumerable<string> properties { get; set; }


        public Weapons(string type, string name, int? costAmount, string coinType, int? diceAmount, int? diceFace, int? damageInt, string damageName, string weight, IEnumerable<string> properties)
        {
            this.type = type;
            this.name = name;
            this.costAmount = costAmount;
            this.coinType = coinType;
            this.weight = weight;
            this.damageDiceFace = diceFace;
            this.damageDiceAmount = diceAmount;
            this.damageInt = damageInt;
            this.damageName = damageName;
            this.properties = properties;
        }
    }

   
}
